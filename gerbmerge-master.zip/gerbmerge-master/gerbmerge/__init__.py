# Placeholder for GerbMerge package

# make version info available at top level
from __version_info__ import __version__
