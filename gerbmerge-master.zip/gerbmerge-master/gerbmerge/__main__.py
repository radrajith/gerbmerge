import gerbmerge

# Hook to call the self standing program when used with `python -m gerbmerge`
if __name__ == "__main__":
  gerbmerge.main()
